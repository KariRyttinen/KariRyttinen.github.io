Project structure for QAutomate products
 - QAutoFlow (previously QAutoFlow + QAutoNative + QAutoRobot)
 - QAutoCloud

Depends on QAutomateLibrary, install with pip:
 `pip install -U git+https://github.com/qautomateoy/QAutomateLibrary.git#egg=QAutomateLibrary`


```
/documentation
    readme.md
/resources - required
    /data
        sample_data_file.txt
    /python_libraries - required
        /shared_keywords - required
            /components - required
            /models - required
            AllComponents.py - required, do not modify manually!
            AllModels.py - required, do not modify manually!
    /shared_robot_keywords - required
/results - required
    sample_result_file.txt
/robots - required
    /some_rpa_task - recommended that file names match the directory name
        QAutoRPA_settings.json - required for rpa robots
        some_rpa_task.robot
        some_rpa_task.resource - optional, recommended, everything could also be included in the robot file 
    /some_automated_test
        some_automated_test.robot
        some_automated_test_keywords.resource - optional, recommended to split resources into multiple files for complex tests or rpa tasks
        some_automated_test_setup.resource - optional, recommended to split resources into multiple files for complex tests or rpa tasks
        some_automated_test_variables.resource - optional, recommended to split resources into multiple files for complex tests or rpa tasks
```