from robot.api.deco import keyword
from qautomatelibrary.BrowserExtension import BrowserExtension
#from shared_keywords.AllModels import AllModels
browser = BrowserExtension()
#model_keywords = AllModels()
class component:
    HOVER_DROPDOWN = "id=dropdown"
    CLICK_KIRJAUDU = "//div[@id='nav-links']/descendant::a[contains(text(), 'Kirjaudu')]"
    FILL_TEXT_KTTUNNUS = "id=uname"
    FILL_TEXT_SALASANA = "id=pword"
    CLICK_SENDBUTTON = "id=sendbutton"
    CLICK_KIRJAUDUULOS = "//div[@id='nav-links']/descendant::a[contains(text(), 'Kirjaudu ulos')]"

    def __init__(self):
        """
        Pagemodel initialization
        """
        pass

    @keyword
    def lantapahtuma(self,fill_text_kttunnus,fill_text_salasana):
        browser.hover(selector=self.HOVER_DROPDOWN)
        browser.click(selector=self.CLICK_KIRJAUDU)
        browser.fill_text(selector=self.FILL_TEXT_KTTUNNUS, txt=str(fill_text_kttunnus))
        browser.fill_text(selector=self.FILL_TEXT_SALASANA, txt=str(fill_text_salasana))
        browser.click(selector=self.CLICK_SENDBUTTON)
        browser.hover(selector=self.HOVER_DROPDOWN)
        browser.click(selector=self.CLICK_KIRJAUDUULOS)
