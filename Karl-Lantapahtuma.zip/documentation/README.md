RPA process technical overview

Process description
* Process description as detailed as possible
* Process steps
* graphml-process flowchart so it can be edited later on if needed (preferably done with QAutocapture)
  * GRAPHML SOURCE FILE
  * GRAPH PNG FILE
  * LINK TO GRAPH PNG FILE

Client environment
* A list of customer environments so far as it is relevant to the operation and support of the robot
* Web interface, Native UI, or API (SOAP API, REST API)

Access and credentials
* To what relevant systems the robot has credentials/access to?
* If there are credentials used by the robot, are the credentials storage e.g Bitwarden? Are there anything special regarding credentials (e.g., expiration every 3 months etc.)
* VPN and other connections? Install instructions?

Project structure
* Project structure overview, any exceptions?
* Are there reusable components in the development work?

External dependencies/libraries used
* Which libraries were used in the development work? (Python libraries )
* External dependencies and libraries listed and opened as relevant to the robot development

Special rules, requirements, and security issues
* Whether the robot has special rules or requirements?
* Robot security issues listed and opened.

Operative system
* Windows, Linux or other?

GDPR
* Is there anything GDPR related to the robot’s operation? How has it been taken into account?
* Any personal data used?
